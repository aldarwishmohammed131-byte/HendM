export default function Checkout(){
  return <div className="max-w-lg mx-auto card p-6">
    <h1 className="text-2xl font-semibold">Checkout (Stub)</h1>
    <p className="text-base-sub mt-3">Integrate Stripe/PayPal/Moyasar/Tap later.</p>
  </div>;
}
